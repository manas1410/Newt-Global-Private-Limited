password = input("Enter the password: ")

while password != "pass123":
    password = input("Enter the password: ")

print("Password was Correct!")